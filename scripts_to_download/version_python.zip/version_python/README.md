# Notes sur la version python3 du projet

## Premier lancement

Lancer python3 settings.py une fois avant de lancer "main.py".

Ne surtout pas déplacer le fichier settings !! Sinon tous les paths changeront !!
