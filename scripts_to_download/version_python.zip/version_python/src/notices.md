# Forme de dicoInfo

dicoInfos = {'numero_dossier' : {
                'infos_dossier' : {
                    'langue' : langue,
                    'requete' : query } ,
                'contenu_dossier' : {
                    id_elt : { lien_web : 'https?//...',
                    lien_aspiration : '....html',
                    lien_dumping : '....txt' ,
                    charset_initial: 'charset',
                    lien_contexte_txt : '...txt' ,
                    lien_contexte_txt : '...html' .
                },
                .....
                }
